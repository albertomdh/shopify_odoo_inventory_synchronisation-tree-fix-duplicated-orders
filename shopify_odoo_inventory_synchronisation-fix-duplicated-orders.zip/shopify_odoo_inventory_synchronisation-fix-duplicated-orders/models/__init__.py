from . import res_company
from . import stock_move
from . import res_partner
from . import sale